# OpenAI Robot Starter - Windows PowerShell installer
# Run: powershell -ExecutionPolicy Bypass -File .\install.ps1
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host '=== OpenAI Robot Starter ===' -ForegroundColor Cyan

$py = Get-Command py -ErrorAction SilentlyContinue
if ($py) {
    & py -3 --version | Out-Host
    if ($LASTEXITCODE -ne 0) { throw 'Python 3 could not be launched.' }
    & py -3 -m venv .venv
} else {
    $python = Get-Command python -ErrorAction SilentlyContinue
    if (-not $python) {
        $winget = Get-Command winget -ErrorAction SilentlyContinue
        if (-not $winget) { throw 'Install Python 3.11+ from python.org, then rerun. Neither Python nor winget was found.' }
        Write-Host 'Python was not found. Installing Python using winget...' -ForegroundColor Yellow
        & winget install --id Python.Python.3.12 --exact --source winget --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) { throw 'Python installation failed. Install Python manually and rerun.' }
        throw 'Python installed. Open a NEW PowerShell terminal, then rerun install.ps1 so PATH is refreshed.'
    }
    & python --version | Out-Host
    & python -m venv .venv
}
if ($LASTEXITCODE -ne 0) { throw 'Creating the virtual environment failed.' }
$venvPy = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
& $venvPy -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed.' }
& $venvPy -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
if (-not (Test-Path '.env')) { Copy-Item '.env.example' '.env' }
Write-Host "`nInstallation complete." -ForegroundColor Green
Write-Host '1. Edit .env with OPENAI_API_KEY and optional robot settings.'
Write-Host '2. Run: .\.venv\Scripts\python.exe robot.py --camera-test'
Write-Host '3. Run: .\.venv\Scripts\python.exe robot.py --ask "Describe what you see"'
Write-Host 'No motors will be activated by this starter.'
