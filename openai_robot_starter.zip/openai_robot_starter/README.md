# OpenAI robot starter (Windows)

This sets up a PC-hosted Python vision prototype; it **does not** control motors yet.

1. Unzip to a writable folder.
2. Open PowerShell in that folder.
3. Run `powershell -ExecutionPolicy Bypass -File .\install.ps1`.
4. Edit `.env` and replace `PASTE_YOUR_API_KEY_HERE` with your OpenAI API key (only needed for AI analysis).
5. Run `.\.venv\Scripts\python.exe robot.py --camera-test` to save a webcam image.
6. Run `.\.venv\Scripts\python.exe robot.py --ask "What objects do you see?"` to analyze one frame.

You need an available camera and internet connection. OpenAI API usage is billed separately from ChatGPT subscriptions. API keys should stay private. `ROBOT_HOST`, `ROBOT_PORT`, and `ROBOT_SERIAL_PORT` are placeholders reserved for later ESP32 communication; none are activated. This starter sends only one compressed frame per `--ask` call, not live 30 FPS video. For real motion later, add local collision avoidance, a watchdog timeout, speed limits, an emergency stop, and hardware-specific motor firmware before attempting autonomy.
