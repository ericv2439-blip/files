"""Safe camera/AI starter. No motor output is implemented."""
import argparse
import base64
import os
import sys

import cv2
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()


def capture_frame():
    raw = os.getenv('CAMERA_INDEX', '0')
    source = int(raw) if raw.isdigit() else raw
    camera = cv2.VideoCapture(source)
    try:
        if not camera.isOpened():
            raise RuntimeError(f'Cannot open camera {source}. Check CAMERA_INDEX in .env.')
        ok, frame = camera.read()
        if not ok:
            raise RuntimeError('Camera opened but produced no frame.')
        return frame
    finally:
        camera.release()


def ask_about_frame(question):
    key = os.getenv('OPENAI_API_KEY', '')
    if not key or key == 'PASTE_YOUR_API_KEY_HERE':
        raise RuntimeError('Set OPENAI_API_KEY in .env before running --ask.')
    frame = capture_frame()
    frame = cv2.resize(frame, (min(1024, frame.shape[1]), min(768, frame.shape[0])))
    success, encoded = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 75])
    if not success:
        raise RuntimeError('Could not encode camera image.')
    image_uri = 'data:image/jpeg;base64,' + base64.b64encode(encoded.tobytes()).decode('ascii')
    client = OpenAI(api_key=key, timeout=30.0)
    response = client.responses.create(
        model=os.getenv('OPENAI_MODEL', 'gpt-4.1-mini'),
        input=[{'role': 'user', 'content': [
            {'type': 'input_text', 'text': question},
            {'type': 'input_image', 'image_url': image_uri},
        ]}],
        max_output_tokens=250,
    )
    print(response.output_text)


def main():
    parser = argparse.ArgumentParser(description='Camera + OpenAI starter (no motors)')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--camera-test', action='store_true', help='Save one camera frame to camera_test.jpg')
    group.add_argument('--ask', metavar='QUESTION', help='Ask GPT about one camera frame')
    args = parser.parse_args()
    if args.camera_test:
        frame = capture_frame()
        if not cv2.imwrite('camera_test.jpg', frame):
            raise RuntimeError('Failed to save camera_test.jpg')
        print('Saved camera_test.jpg')
    else:
        ask_about_frame(args.ask)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'Error: {exc}', file=sys.stderr)
        sys.exit(1)
