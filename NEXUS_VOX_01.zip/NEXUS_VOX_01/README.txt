NEXUS // VOX-01

Open NEXUS_VOX_01.html in a browser to play the interactive soundboard.
The sounds/ folder contains six standalone WAV files.

Python playback example (Windows):
  import winsound
  winsound.PlaySound("sounds/happy.wav", winsound.SND_FILENAME)

No installation or internet required.
